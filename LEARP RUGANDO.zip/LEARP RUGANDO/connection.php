<?php
if(isset($_POST[''])){
    $Name =$_POST['name'];
    $Email =$_POST['email'];
    $Message = $_POST['message'];
    $con = mysqli_connect('localhost','root','','contact');

    if($Name != "" and $Email != "" and $Message != ""){
        $q="INSERT INTO contact(Name,Email,Message) values";
       " ('$Name','$Email','$Message')";
        

        if(mysqli_query($con,$q)){
            echo 'your message is sent';
        }
        else{
            echo'fill the box';
        }

    }
    
    else{
        echo 'please fill te boxes';
    }
}



